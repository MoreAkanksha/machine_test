package com.Nemap_MachineTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NemapMachineTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(NemapMachineTestApplication.class, args);
		System.out.println("-----Welcome in Nemap Machine Test-----");
	}

}
